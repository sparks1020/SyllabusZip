# SyllabusZip
this was supposed to be the materials view, but since i diverted to working on the rest of the project, it also includes the python script and project to analyze the OCR output.

This describes the flow of code in this project

#Step 1
User logs into website and uploads a syllabus
syllabus goes to blob storage

#Step 2
Blob storage triggers a C sharp function to analyze the document and put it into Azure Cosmos DB as a json document (as of 1/1/21)
This will trigger the analyze function

#Step 3
Another Azure function (as of 1/1/21) to analyze the json document and put it into the SQL database into tables

#Step 4
website will update according to user's account with relevant syllabus data
