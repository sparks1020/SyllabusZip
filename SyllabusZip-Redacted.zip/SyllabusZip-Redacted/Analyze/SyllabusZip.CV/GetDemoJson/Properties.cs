﻿using System.Runtime.CompilerServices;

[assembly:InternalsVisibleTo("AnalyzerTests")]