﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace SyllabusZip.Migrations
{
    public partial class AddAuthTokenSecret : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "ee683553-a6d1-4efc-b275-f50ee61e1d36");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "ef04c432-7630-4da3-999c-c71c5c9993fa");

            migrationBuilder.AddColumn<string>(
                name: "AuthTokenSecret",
                table: "SyllabusSources",
                nullable: true);

            migrationBuilder.InsertData(
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Name", "NormalizedName" },
                values: new object[] { "40644734-2ce6-42be-a2d5-4dd39e5da659", "dabc61dd-14ba-4ce1-a610-848328270383", "Visitor", "VISITOR" });

            migrationBuilder.InsertData(
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Name", "NormalizedName" },
                values: new object[] { "6d53b17c-30b9-4901-8d42-48d52d7005c4", "0a829061-37f7-4833-b537-36983d4889b2", "Administrator", "ADMINISTRATOR" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "40644734-2ce6-42be-a2d5-4dd39e5da659");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "6d53b17c-30b9-4901-8d42-48d52d7005c4");

            migrationBuilder.DropColumn(
                name: "AuthTokenSecret",
                table: "SyllabusSources");

            migrationBuilder.InsertData(
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Name", "NormalizedName" },
                values: new object[] { "ef04c432-7630-4da3-999c-c71c5c9993fa", "c74e33df-09d9-4967-895a-371ef5e85fb3", "Visitor", "VISITOR" });

            migrationBuilder.InsertData(
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Name", "NormalizedName" },
                values: new object[] { "ee683553-a6d1-4efc-b275-f50ee61e1d36", "052c7539-8fcd-4d01-9cdf-fb00a50d8ec1", "Administrator", "ADMINISTRATOR" });
        }
    }
}
