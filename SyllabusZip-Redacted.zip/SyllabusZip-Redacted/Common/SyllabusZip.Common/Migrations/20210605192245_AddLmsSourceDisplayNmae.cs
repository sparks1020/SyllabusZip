﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace SyllabusZip.Migrations
{
    public partial class AddLmsSourceDisplayNmae : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "320bafa2-b4ad-4e33-ba6c-cf095acc1e83");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "73351ec7-a96e-42c0-9ec9-fd3449ff46de");

            migrationBuilder.AddColumn<string>(
                name: "DisplayName",
                table: "SyllabusSources",
                nullable: true);

            migrationBuilder.InsertData(
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Name", "NormalizedName" },
                values: new object[] { "ef04c432-7630-4da3-999c-c71c5c9993fa", "c74e33df-09d9-4967-895a-371ef5e85fb3", "Visitor", "VISITOR" });

            migrationBuilder.InsertData(
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Name", "NormalizedName" },
                values: new object[] { "ee683553-a6d1-4efc-b275-f50ee61e1d36", "052c7539-8fcd-4d01-9cdf-fb00a50d8ec1", "Administrator", "ADMINISTRATOR" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "ee683553-a6d1-4efc-b275-f50ee61e1d36");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "ef04c432-7630-4da3-999c-c71c5c9993fa");

            migrationBuilder.DropColumn(
                name: "DisplayName",
                table: "SyllabusSources");

            migrationBuilder.InsertData(
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Name", "NormalizedName" },
                values: new object[] { "73351ec7-a96e-42c0-9ec9-fd3449ff46de", "fe48663e-1356-43c8-aeef-9cb47d0aa9af", "Visitor", "VISITOR" });

            migrationBuilder.InsertData(
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Name", "NormalizedName" },
                values: new object[] { "320bafa2-b4ad-4e33-ba6c-cf095acc1e83", "23572bbd-fcd0-4b5a-a191-1433b93e7488", "Administrator", "ADMINISTRATOR" });
        }
    }
}
