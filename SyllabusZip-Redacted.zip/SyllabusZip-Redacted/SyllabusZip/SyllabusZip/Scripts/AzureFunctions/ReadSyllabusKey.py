﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SyllabusZip.Scripts.AzureFunctions
{
    public class ReadSyllabus
    {
        cog_key = 'REDACTED'
        cog_endpoint = 'https://eastus.api.cognitive.microsoft.com/'

        print('Ready to use cognitive services at {} using key {}'.format(cog_endpoint, cog_key))
    }
}
