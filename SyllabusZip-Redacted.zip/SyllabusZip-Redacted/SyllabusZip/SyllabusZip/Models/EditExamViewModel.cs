﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SyllabusZip.Models
{
    public class EditExamViewModel
    {
        public string Date { get; set; }
        public string ExamId { get; set; }
        public string ExamType { get; set; }
    }
}
