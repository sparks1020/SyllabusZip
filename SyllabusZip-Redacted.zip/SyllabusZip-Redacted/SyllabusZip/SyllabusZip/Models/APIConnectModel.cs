﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SyllabusZip.Models
{
    public class APIConnectModel
    {
        public string UrlText { get; set; }
    }
}
