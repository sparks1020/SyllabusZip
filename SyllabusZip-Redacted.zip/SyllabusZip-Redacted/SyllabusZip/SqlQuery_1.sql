﻿truncate table Contact; go
truncate table Assignments; go
truncate table Exams; go
truncate table Materials; go